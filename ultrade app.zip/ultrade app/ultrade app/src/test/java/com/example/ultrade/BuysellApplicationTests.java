package com.example.ultrade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuysellApplicationTests {

	@Test
	void contextLoads() {
	}

}
